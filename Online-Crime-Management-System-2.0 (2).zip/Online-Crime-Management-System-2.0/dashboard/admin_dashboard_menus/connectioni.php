<?php
	$servername = "localhost";
	$username="root";
	$password="";
	$dbname="crime_management";
	
	$con =mysqli_connect($servername, $username,$password,$dbname);

	/*if($con){
		echo "Connection Succesful";
	}
	else {
		echo "No Connection";
	} */


?>